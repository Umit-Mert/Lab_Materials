# coding: utf-8


from __future__ import absolute_import

import getpass

# python 2 and python 3 compatibility library
# from six import iteritems

from .configuration import Configuration
from .api_client import ApiClient
from .apis.batchdeploy_api import BatchdeployApi
import os
import getpass
# import apis into api package


class BatchClient(BatchdeployApi):
    """
    NOTE:Wrapper class for scheuler client
    """

    def __init__(self, host=None):
        #BluemixIDToken = getpass.getpass('ibm.ax.token')
        BlueIDToken = getpass.getpass('ibm.ax.token')
        Token = "Bearer " + BlueIDToken

        env = os.environ.get('APP_ENV_ENVIRONMENT')
        domain = os.environ.get('APP_ENV_BM_DOMAIN')

        #check environment
        if host is None:
            if(env == "prod" and domain == 'ng.bluemix.net'):
                host = "http://batch-deploy-prod.spark.bluemix.net:12200"
            elif (env=="prod" and domain == 'stage1.ng.bluemix.net'):
                host = "http://169.54.236.171:12200"
            elif (env=="dev" and domain == 'stage1.ng.bluemix.net'):
                host = "http://169.54.236.171:12200"
            else:
                host ="http://169.54.236.171:12200"

        api_client = ApiClient(host)

        api_client.set_default_header("Authorization",Token)
        super(self.__class__,self).__init__(api_client)


